<?php

use App\Http\Controllers\API\CategoryController;
use App\Http\Controllers\API\MemberController;
use App\Http\Controllers\API\RestaurantController;
use App\Http\Controllers\API\TableController;
use App\Http\Controllers\API\StaffController;
use App\Http\Controllers\API\MenuController;
use App\Http\Controllers\MobileController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


// Restaurant
Route::post('/login', [RestaurantController::class, 'login']);
Route::post('/staffLogin', [MemberController::class, 'staffLogin']);
Route::post('/restaurant/registration', [RestaurantController::class, 'restaurantRegistration']);

Route::get('/restaurant', [RestaurantController::class, 'getRestaurants']);
Route::get('/restaurant/{id?}', [RestaurantController::class, 'getRestaurantById']);

Route::middleware('auth.member')->group(function () {
    Route::get('/tableList', [MobileController::class, 'tableList']);
    Route::get('/menuList', [MobileController::class, 'menuList']);
    Route::get('/categoryList', [MobileController::class, 'categoryList']);
    // Route::get('/addToCart', [MobileController::class, 'addToCart']);
    Route::post('/addToCart', [MobileController::class, 'addToCart']);
    Route::post('/changeTableStatus', [MobileController::class, 'changeTableStatus']);
    Route::post('/viewCart', [MobileController::class, 'viewCart']);
    Route::post('/deleteCart', [MobileController::class, 'deleteCart']);
    Route::post('/changeCart', [MobileController::class, 'changeCart']);
    Route::get('/orderView', [MobileController::class, 'orderView']);
});
Route::middleware('auth.restaurant')->group(function () {

    //table routes
    Route::get('/table', [TableController::class, 'getTables']);
    Route::get('/table/byId/{id?}', [TableController::class, 'getTableById']);
    Route::post('/table', [TableController::class, 'addTables']);
    Route::put('/table/edit/{id?}', [TableController::class, 'editTable']);
    Route::delete('/table/{id?}', [TableController::class, 'deleteTable']);
    // trash
    Route::get('/trashTable', [TableController::class, 'getTrashTable']);
    Route::put('/table/restore/{id?}', [TableController::class, 'restoreDeletedTable']);
    Route::delete('/table/delete/{id?}', [TableController::class, 'permanentDeleteTable']);


    // staff routes
    Route::get('/staff', [MemberController::class, 'getStaffs']);
    Route::get('/staff/byId/{id?}', [MemberController::class, 'getStaffById']);
    Route::get('/trashStaff', [MemberController::class, 'getTrashStaffs']);
    Route::post('/staff', [MemberController::class, 'addStaffs']);
    Route::put('/staff/{id?}', [MemberController::class, 'editStaff']);
    Route::delete('/staff/{id?}', [MemberController::class, 'deleteStaff']);
    // trash 
    Route::get('/trashStaff', [MemberController::class, 'getTrashStaff']);
    Route::put('/staff/restore/{id?}', [MemberController::class, 'restoreDeletedStaff']);
    Route::delete('/staff/delete/{id?}', [MemberController::class, 'permanentDeleteStaff']);


    // Category api
    Route::get('/categories', [CategoryController::class, 'getCategories']);
    Route::get('/category/byId/{id?}', [CategoryController::class, 'getCategoryById']);
    Route::post('/categories', [CategoryController::class, 'addCategories']);
    Route::POST('/category/{id?}', [CategoryController::class, 'editCategories']);
    Route::delete('/category/{id?}', [CategoryController::class, 'deleteCategories']);
    // trash
    Route::get('/trashCategories', [CategoryController::class, 'getTrashCategories']);
    Route::put('/category/restore/{id?}', [CategoryController::class, 'restoreDeletedCategory']);
    Route::delete('/category/delete/{id?}', [CategoryController::class, 'permanentDeleteCategory']);

    // menu api
    Route::get('/menu', [MenuController::class, 'getMenus']);
    Route::post('/menu', [MenuController::class, 'addMenu']);
    Route::post('/menu/edit/{id?}', [MenuController::class, 'editMenu']);
    // trash
    Route::get('/trashMenu', [MenuController::class, 'getTrashMenus']);
    Route::put('/menu/restore/{id?}', [MenuController::class, 'restoreDeletedMenu']);
    Route::delete('/menu/delete/{id?}', [MenuController::class, 'permanentDeleteMenu']);
    Route::get('/menu/byId/{id?}', [MenuController::class, 'showMenu']);
    Route::get('/trashMenu', [MenuController::class, 'getTrashMenus']);
});

Route::get('/pass', [CategoryController::class, 'addPassword']);
